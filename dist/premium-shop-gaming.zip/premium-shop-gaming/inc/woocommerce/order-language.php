<?php
/**
 * The customer's language follows the order: it is saved at checkout and
 * every e-mail sent to the customer (subject and content) — and the PDF
 * invoice of "PDF Invoices & Packing Slips for WooCommerce" — uses it, even
 * when the e-mail is sent later from the (German) dashboard.
 *
 * @package Premium_Shop
 */

defined( 'ABSPATH' ) || exit;

/**
 * Language code saved on an order ('' when unknown).
 *
 * @param WC_Order|int $order Order.
 * @return string
 */
function premium_shop_order_language( $order ) {
	$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
	if ( ! $order ) {
		return '';
	}
	$lang = (string) $order->get_meta( '_ps_language' );
	return array_key_exists( $lang, premium_shop_languages() ) ? $lang : '';
}

/**
 * Language of the visitor placing the order.
 *
 * @return string
 */
function premium_shop_visitor_language() {
	if ( function_exists( 'premium_shop_builtin_applies' ) && premium_shop_builtin_applies() ) {
		return premium_shop_builtin_language();
	}
	return premium_shop_current_language();
}

/**
 * Save the language on new orders (classic and block checkout) and on the
 * customer account.
 *
 * @param WC_Order $order Order.
 */
function premium_shop_save_order_language( $order ) {
	if ( ! $order instanceof WC_Order || $order->get_meta( '_ps_language' ) ) {
		return;
	}
	$lang = premium_shop_visitor_language();
	if ( ! $lang ) {
		return;
	}
	$order->update_meta_data( '_ps_language', $lang );
	if ( $order->get_customer_id() ) {
		update_user_meta( $order->get_customer_id(), '_ps_language', $lang );
	}
}
add_action( 'woocommerce_checkout_create_order', 'premium_shop_save_order_language', 5 );
add_action( 'woocommerce_store_api_checkout_update_order_meta', 'premium_shop_save_order_language', 5 );

/**
 * Remember the language of customers who create an account.
 *
 * @param int $customer_id User ID.
 */
function premium_shop_save_customer_language( $customer_id ) {
	$lang = premium_shop_visitor_language();
	if ( $lang && ! is_admin() ) {
		update_user_meta( $customer_id, '_ps_language', $lang );
	}
}
add_action( 'woocommerce_created_customer', 'premium_shop_save_customer_language', 5 );

/**
 * Language for the object of an e-mail (order, refund, customer).
 *
 * @param mixed $object E-mail object.
 * @return string
 */
function premium_shop_email_object_language( $object ) {
	if ( $object instanceof WC_Order_Refund ) {
		$object = wc_get_order( $object->get_parent_id() );
	}
	if ( $object instanceof WC_Order ) {
		$lang = premium_shop_order_language( $object );
		if ( ! $lang && $object->get_customer_id() ) {
			$lang = (string) get_user_meta( $object->get_customer_id(), '_ps_language', true );
		}
		return $lang;
	}
	if ( $object instanceof WP_User ) {
		return (string) get_user_meta( $object->ID, '_ps_language', true );
	}
	return '';
}

/**
 * Switch every translation (WordPress, WooCommerce, theme) to a language.
 *
 * @param string $lang Language code.
 * @return bool Whether the locale was switched.
 */
function premium_shop_switch_language( $lang ) {
	if ( ! $lang || ! array_key_exists( $lang, premium_shop_languages() ) ) {
		return false;
	}
	$locale = premium_shop_locale_for( $lang );
	// switch_to_locale() returns false when WordPress already runs in that
	// locale; the translations are (re)loaded explicitly either way.
	$GLOBALS['premium_shop_locale_switched'] = (bool) switch_to_locale( $locale );
	premium_shop_load_translations( $locale );
	$GLOBALS['premium_shop_switched_language'] = $lang;
	do_action( 'premium_shop_language_switched', $lang );
	return true;
}

/**
 * Load the WooCommerce and theme translations of a locale.
 *
 * @param string $locale Locale.
 */
function premium_shop_load_translations( $locale ) {
	if ( function_exists( 'WC' ) ) {
		unload_textdomain( 'woocommerce', true );
		if ( 'en_US' !== $locale ) {
			load_textdomain( 'woocommerce', WP_LANG_DIR . '/plugins/woocommerce-' . $locale . '.mo', $locale );
		}
	}
	unload_textdomain( 'premium-shop', true );
	if ( 'en_US' !== $locale ) {
		load_textdomain( 'premium-shop', PREMIUM_SHOP_DIR . '/languages/' . $locale . '.mo', $locale );
	}
	// PDF Invoices & Packing Slips for WooCommerce: invoice titles and labels
	// ("Facture", "Numéro de commande"…) in the same language.
	if ( function_exists( 'WPO_WCPDF' ) ) {
		$domain = 'woocommerce-pdf-invoices-packing-slips';
		unload_textdomain( $domain, true );
		if ( 'en_US' !== $locale ) {
			load_textdomain( $domain, WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo', $locale );
			load_textdomain( $domain, WP_LANG_DIR . '/plugins/' . $domain . '-' . $locale . '.mo', $locale );
		}
	}
}

/**
 * While an e-mail or a document is switched to the customer's language,
 * plugins that reload their translations use that language too. PDF Invoices
 * & Packing Slips reloads its own just before building the e-mail
 * attachment, with the language of the dashboard user: the invoice of a
 * French order completed from the dashboard came out in that language (or in
 * English) instead of French.
 *
 * @param string $locale Locale.
 * @return string
 */
function premium_shop_switched_plugin_locale( $locale ) {
	if ( ! empty( $GLOBALS['premium_shop_switched_language'] ) ) {
		return premium_shop_locale_for( $GLOBALS['premium_shop_switched_language'] );
	}
	return $locale;
}
add_filter( 'plugin_locale', 'premium_shop_switched_plugin_locale', 99 );

/**
 * After PDF Invoices & Packing Slips reloaded its translations for an e-mail
 * attachment: back to the customer's language.
 */
function premium_shop_pdf_attachment_language() {
	if ( ! empty( $GLOBALS['premium_shop_switched_language'] ) ) {
		premium_shop_load_translations( premium_shop_locale_for( $GLOBALS['premium_shop_switched_language'] ) );
	}
}
add_action( 'wpo_wcpdf_reload_attachment_translations', 'premium_shop_pdf_attachment_language', 99 );

/**
 * Undo premium_shop_switch_language().
 */
function premium_shop_restore_language() {
	if ( empty( $GLOBALS['premium_shop_switched_language'] ) ) {
		return;
	}
	unset( $GLOBALS['premium_shop_switched_language'] );
	if ( ! empty( $GLOBALS['premium_shop_locale_switched'] ) ) {
		restore_previous_locale();
	}
	unset( $GLOBALS['premium_shop_locale_switched'] );
	premium_shop_load_translations( determine_locale() );
	do_action( 'premium_shop_language_switched', '' );
}

/**
 * Customer e-mails: WooCommerce would switch to the site language before the
 * order is known; the theme switches to the order language instead, as soon
 * as the recipient is read (before the subject and content are built).
 *
 * @param bool     $allow Allow WooCommerce's own switch.
 * @param WC_Email $email E-mail.
 * @return bool
 */
function premium_shop_email_skip_site_locale( $allow, $email = null ) {
	if ( $email instanceof WC_Email && $email->is_customer_email() ) {
		return false;
	}
	return $allow;
}
add_filter( 'woocommerce_allow_switching_email_locale', 'premium_shop_email_skip_site_locale', 20, 2 );
add_filter( 'woocommerce_allow_restoring_email_locale', 'premium_shop_email_skip_site_locale', 20, 2 );

/**
 * Switch to the customer's language when a customer e-mail reads its recipient.
 *
 * @param string   $recipient Recipient.
 * @param mixed    $object    Order, user…
 * @param WC_Email $email     E-mail.
 * @return string
 */
function premium_shop_email_switch_language( $recipient, $object = null, $email = null ) {
	if ( ! $email instanceof WC_Email || premium_shop_email_switched( $email ) ) {
		return $recipient;
	}
	// A previous e-mail of the same request that did not restore (some
	// e-mails skip WooCommerce's restore step): start from a clean state.
	premium_shop_restore_language();
	// Customer e-mails: the customer's language. Shop e-mails (new order…):
	// always the shop language, even when the order is placed in French.
	$lang = $email->is_customer_email() ? premium_shop_email_object_language( $object ) : '';
	if ( ! $lang ) {
		$lang = premium_shop_default_language();
	}
	if ( premium_shop_switch_language( $lang ) ) {
		premium_shop_email_switched( $email, true );
		// WooCommerce keeps the default subject/heading of the first e-mail
		// sent in its settings cache, and the default texts (e.g. "additional
		// content") in its form fields, built in the visitor's language:
		// rebuild both for this language.
		if ( method_exists( $email, 'init_form_fields' ) ) {
			$email->init_form_fields();
		}
		$email->init_settings();
	}
	return $recipient;
}

/**
 * Remember which e-mail objects switched the language.
 *
 * @param WC_Email  $email E-mail.
 * @param bool|null $set   New state (null: read).
 * @return bool
 */
function premium_shop_email_switched( $email, $set = null ) {
	static $switched = array();
	$key = spl_object_id( $email );
	if ( null !== $set ) {
		if ( $set ) {
			$switched[ $key ] = true;
		} else {
			unset( $switched[ $key ] );
		}
	}
	return ! empty( $switched[ $key ] );
}

/**
 * Register the recipient filter for every customer e-mail.
 *
 * @param array $emails E-mail classes.
 * @return array
 */
function premium_shop_email_language_hooks( $emails ) {
	foreach ( (array) $emails as $email ) {
		if ( $email instanceof WC_Email ) {
			add_filter( 'woocommerce_email_recipient_' . $email->id, 'premium_shop_email_switch_language', 1, 3 );
		}
	}
	return $emails;
}
add_filter( 'woocommerce_email_classes', 'premium_shop_email_language_hooks', 999 );

/**
 * Back to the previous language after the e-mail was sent.
 *
 * @param bool     $allow Allow restoring.
 * @param WC_Email $email E-mail.
 * @return bool
 */
function premium_shop_email_restore_language( $allow, $email = null ) {
	if ( $email instanceof WC_Email && premium_shop_email_switched( $email ) ) {
		premium_shop_email_switched( $email, false );
		premium_shop_restore_language();
	}
	return $allow;
}
add_filter( 'woocommerce_allow_restoring_email_locale', 'premium_shop_email_restore_language', 30, 2 );

/**
 * Also restore once the e-mail is sent (covers e-mails without a restore step).
 *
 * @param bool     $sent  Sent.
 * @param string   $id    E-mail ID.
 * @param WC_Email $email E-mail.
 */
function premium_shop_email_sent_restore( $sent, $id = '', $email = null ) {
	premium_shop_email_restore_language( true, $email );
}
add_action( 'woocommerce_email_sent', 'premium_shop_email_sent_restore', 99, 3 );

/**
 * PDF Invoices & Packing Slips for WooCommerce: documents in the order's
 * language (also when downloaded from the dashboard).
 *
 * @param string $type     Document type.
 * @param object $document Document.
 */
function premium_shop_pdf_switch_language( $type = '', $document = null ) {
	if ( ! empty( $GLOBALS['premium_shop_switched_language'] ) ) {
		return; // Already in the order language (e-mail attachment).
	}
	$order = is_object( $document ) && isset( $document->order ) ? $document->order : null;
	$lang  = premium_shop_email_object_language( $order );
	if ( $lang && premium_shop_switch_language( $lang ) ) {
		$GLOBALS['premium_shop_pdf_switched'] = true;
	}
}
add_action( 'wpo_wcpdf_before_html', 'premium_shop_pdf_switch_language', 1, 2 );

/**
 * After the PDF: previous language.
 */
function premium_shop_pdf_restore_language() {
	if ( ! empty( $GLOBALS['premium_shop_pdf_switched'] ) ) {
		unset( $GLOBALS['premium_shop_pdf_switched'] );
		premium_shop_restore_language();
	}
}
add_action( 'wpo_wcpdf_after_html', 'premium_shop_pdf_restore_language', 99 );

/**
 * Order screen: show and change the customer's language.
 *
 * @param WC_Order $order Order.
 */
function premium_shop_order_language_field( $order ) {
	$current = premium_shop_order_language( $order );
	?>
	<p class="form-field form-field-wide">
		<label for="ps_order_language"><?php esc_html_e( 'Customer language (e-mails, invoice)', 'premium-shop' ); ?></label>
		<select id="ps_order_language" name="ps_order_language" style="width:100%">
			<option value=""><?php esc_html_e( 'Shop language', 'premium-shop' ); ?></option>
			<?php foreach ( premium_shop_languages() as $code => $lang ) : ?>
				<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $current, $code ); ?>><?php echo esc_html( $lang['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php
}
add_action( 'woocommerce_admin_order_data_after_order_details', 'premium_shop_order_language_field' );

/**
 * Save the language chosen in the order screen.
 *
 * @param int $order_id Order ID.
 */
function premium_shop_order_language_save( $order_id ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce checks the order nonce.
	if ( ! isset( $_POST['ps_order_language'] ) || ! current_user_can( 'edit_shop_orders' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	$lang = sanitize_key( wp_unslash( $_POST['ps_order_language'] ) );
	if ( '' === $lang || array_key_exists( $lang, premium_shop_languages() ) ) {
		$order->update_meta_data( '_ps_language', $lang );
		$order->save_meta_data();
	}
}
add_action( 'woocommerce_process_shop_order_meta', 'premium_shop_order_language_save', 20 );

/**
 * Names typed in the WooCommerce settings in the shop language (shipping
 * methods, tax rates, payment methods): shown in the customer's language
 * through the theme catalogue or "[:de]..[:fr].." versions.
 *
 * @param array $rates Shipping rates.
 * @return array
 */
function premium_shop_translate_shipping_rates( $rates ) {
	if ( function_exists( 'premium_shop_i18n_label' ) ) {
		foreach ( $rates as $rate ) {
			if ( $rate instanceof WC_Shipping_Rate ) {
				$rate->set_label( premium_shop_i18n_label( $rate->get_label() ) );
			}
		}
	}
	return $rates;
}
add_filter( 'woocommerce_package_rates', 'premium_shop_translate_shipping_rates', 99 );

/**
 * Shipping rates are kept in the customer session: when the visitor changes
 * language, the label is translated again when it is read (cart, checkout,
 * block checkout / Store API, order).
 *
 * @param string $label Label.
 * @return string
 */
function premium_shop_translate_rate_label( $label ) {
	return function_exists( 'premium_shop_i18n_label' ) && is_string( $label ) ? premium_shop_i18n_label( $label ) : $label;
}
add_filter( 'woocommerce_shipping_rate_label', 'premium_shop_translate_rate_label', 20 );

/**
 * The language is part of the shipping package, so the rates are worked out
 * again (and stored in the right language) after a language change.
 *
 * @param array $packages Packages.
 * @return array
 */
function premium_shop_shipping_packages_language( $packages ) {
	$lang = function_exists( 'premium_shop_current_language' ) ? premium_shop_current_language() : '';
	foreach ( $packages as $i => $package ) {
		$packages[ $i ]['ps_language'] = $lang;
	}
	return $packages;
}
add_filter( 'woocommerce_cart_shipping_packages', 'premium_shop_shipping_packages_language', 20 );

/**
 * Tax rate names and payment method titles/descriptions.
 *
 * @param string $text Text.
 * @return string
 */
function premium_shop_translate_setting_label( $text ) {
	return function_exists( 'premium_shop_i18n_label' ) && is_string( $text ) ? premium_shop_translate_wc_text( $text ) : $text;
}

/**
 * Translate a text typed in the WooCommerce settings: theme catalogue first,
 * then WooCommerce's own texts (e.g. the default bank transfer description
 * saved in French, German or Spanish).
 *
 * @param string $text Text.
 * @return string
 */
function premium_shop_translate_wc_text( $text ) {
	$translated = premium_shop_i18n_label( $text );
	if ( $translated !== $text || '' === trim( $text ) || false !== strpos( $text, '[:' ) ) {
		return $translated;
	}
	$lang = premium_shop_i18n_target();
	$lang = '' !== $lang ? $lang : premium_shop_default_language();
	$key  = 'ps_wct_' . md5( $lang . '|' . $text );
	$hit  = get_transient( $key );
	if ( false === $hit ) {
		$hit = premium_shop_wc_catalogue_translate( $text, $lang );
		set_transient( $key, $hit, WEEK_IN_SECONDS );
	}
	return '' !== $hit ? $hit : $text;
}

/**
 * Look a text up in the WooCommerce language files (any language) and
 * return its version in another language ('' when unknown).
 *
 * @param string $text Text.
 * @param string $lang Target language code.
 * @return string
 */
function premium_shop_wc_catalogue_translate( $text, $lang ) {
	static $files = array();
	// Saved from a text with a placeholder: "… décrites dans notre [privacy_policy]."
	// is "… described in our %s." in the language files.
	if ( preg_match( '/\[(privacy_policy|terms)\]/', $text, $placeholder ) && false === strpos( $text, '%' ) ) {
		$hit = premium_shop_wc_catalogue_translate( str_replace( $placeholder[0], '%s', $text ), $lang );
		return '' !== $hit && 1 === substr_count( $hit, '%s' ) ? str_replace( '%s', $placeholder[0], $hit ) : '';
	}
	$load = static function ( $locale ) use ( &$files ) {
		if ( ! isset( $files[ $locale ] ) ) {
			$files[ $locale ] = false;
			$file             = WP_LANG_DIR . '/plugins/woocommerce-' . $locale . '.mo';
			if ( is_readable( $file ) ) {
				$mo = new MO();
				if ( $mo->import_from_file( $file ) ) {
					$files[ $locale ] = $mo;
				}
			}
		}
		return $files[ $locale ];
	};
	$needle = premium_shop_i18n_key( $text );
	$source = '';
	foreach ( array_keys( premium_shop_languages() ) as $code ) {
		$locale = premium_shop_locale_for( $code );
		if ( 0 === strpos( $locale, 'en_' ) ) {
			continue;
		}
		$mo = $load( $locale );
		if ( ! $mo ) {
			continue;
		}
		foreach ( $mo->entries as $entry ) {
			if ( $entry->is_plural || empty( $entry->translations[0] ) ) {
				continue;
			}
			if ( premium_shop_i18n_key( $entry->translations[0] ) === $needle || premium_shop_i18n_key( $entry->singular ) === $needle ) {
				$source = $entry->singular;
				break 2;
			}
		}
	}
	if ( '' === $source ) {
		return '';
	}
	$target = premium_shop_locale_for( $lang );
	if ( 0 === strpos( $target, 'en_' ) ) {
		return $source;
	}
	$mo = $load( $target );
	return $mo ? (string) $mo->translate( $source ) : '';
}
add_filter( 'woocommerce_rate_label', 'premium_shop_translate_setting_label', 20 );
add_filter( 'woocommerce_gateway_title', 'premium_shop_translate_setting_label', 20 );
add_filter( 'woocommerce_gateway_description', 'premium_shop_translate_setting_label', 20 );

/**
 * Payment and shipping method settings read directly (block checkout, Store
 * API, e-mails): title, description and instructions in the visitor's
 * language. Front end only, so the settings screens keep what you typed.
 *
 * @param array $settings Settings.
 * @return array
 */
function premium_shop_translate_method_settings( $settings ) {
	static $busy = false;
	if ( $busy || ! is_array( $settings ) || is_admin() || ! function_exists( 'premium_shop_i18n_label' ) ) {
		return $settings;
	}
	$busy = true;
	foreach ( array( 'title', 'description', 'instructions' ) as $key ) {
		if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) && '' !== $settings[ $key ] ) {
			$settings[ $key ] = premium_shop_translate_wc_text( $settings[ $key ] );
		}
	}
	$busy = false;
	return $settings;
}

/**
 * Apply the above to every WooCommerce payment / shipping method setting
 * (filters registered once, for the options that exist).
 */
function premium_shop_register_method_settings_filters() {
	if ( is_admin() ) {
		return;
	}
	$names = array( 'woocommerce_bacs_settings', 'woocommerce_cheque_settings', 'woocommerce_cod_settings' );
	foreach ( array_keys( wp_load_alloptions() ) as $name ) {
		if ( 0 === strpos( $name, 'woocommerce_' ) && '_settings' === substr( $name, -9 ) ) {
			$names[] = $name;
		}
	}
	foreach ( array_unique( $names ) as $name ) {
		add_filter( 'option_' . $name, 'premium_shop_translate_method_settings', 20 );
	}
}
add_action( 'init', 'premium_shop_register_method_settings_filters', 0 );

/**
 * Texts WooCommerce saved in its settings in the language WordPress was
 * installed in (privacy texts under the checkout and registration forms,
 * store notice): shown in the visitor's language. Front end only.
 *
 * @param mixed $value Option value.
 * @return mixed
 */
function premium_shop_translate_wc_option_text( $value ) {
	if ( ! is_string( $value ) || '' === trim( $value ) || ( is_admin() && ! wp_doing_ajax() ) || ! function_exists( 'premium_shop_i18n_label' ) ) {
		return $value;
	}
	return premium_shop_translate_wc_text( $value );
}
foreach ( array( 'woocommerce_checkout_privacy_policy_text', 'woocommerce_registration_privacy_policy_text', 'woocommerce_checkout_terms_and_conditions_checkbox_text', 'woocommerce_demo_store_notice' ) as $premium_shop_wc_option ) {
	add_filter( 'option_' . $premium_shop_wc_option, 'premium_shop_translate_wc_option_text', 20 );
}
unset( $premium_shop_wc_option );

/**
 * Common names typed in WooCommerce settings, kept in the catalogue.
 *
 * @return string[]
 */
function premium_shop_order_language_strings() {
	return array(
		__( 'VAT', 'premium-shop' ),
		__( 'Freight forwarding', 'premium-shop' ),
		__( 'Pickup', 'premium-shop' ),
		__( 'Delivery by truck', 'premium-shop' ),
		__( 'Express delivery', 'premium-shop' ),
		__( 'Standard delivery', 'premium-shop' ),
		__( 'Free shipping', 'premium-shop' ),
		__( 'Free delivery', 'premium-shop' ),
		__( 'Flat rate', 'premium-shop' ),
		__( 'Local pickup', 'premium-shop' ),
		__( 'Pickup at the depot', 'premium-shop' ),
		__( 'Delivery with crane truck', 'premium-shop' ),
		__( 'Delivery on pallet', 'premium-shop' ),
		__( 'Bank transfer', 'premium-shop' ),
		__( 'Direct bank transfer', 'premium-shop' ),
		__( 'Check payments', 'premium-shop' ),
		__( 'Wire transfer', 'premium-shop' ),
		__( 'Cash on delivery', 'premium-shop' ),
		__( 'Payment on pickup', 'premium-shop' ),
		__( 'Prepayment', 'premium-shop' ),
		__( 'Invoice', 'premium-shop' ),
	);
}

/**
 * Texts saved inside the cart / checkout blocks when the page was created
 * (e.g. "Dein Warenkorb ist gerade leer!", "Neu im Shop", "Vous serez
 * peut-être intéressé par…"): shown in the visitor's language through
 * WooCommerce's own translations.
 *
 * @param string $html  Block HTML.
 * @param array  $block Block.
 * @return string
 */
function premium_shop_translate_wc_block_texts( $html, $block ) {
	// Shop language too: the blocks were saved in the language WordPress was
	// installed in ("Vous serez peut-être intéressé par…" on a German shop).
	if ( is_admin() || empty( $block['blockName'] ) ) {
		return $html;
	}
	$names = array( 'woocommerce/empty-cart-block', 'woocommerce/empty-mini-cart-contents-block', 'woocommerce/filled-cart-block', 'woocommerce/cart-cross-sells-block', 'woocommerce/proceed-to-checkout-block' );
	if ( ! in_array( $block['blockName'], $names, true ) ) {
		return $html;
	}
	return preg_replace_callback(
		'/>([^<>]*[[:alpha:]][^<>]*)</u',
		static function ( $m ) {
			$text = trim( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) );
			if ( mb_strlen( $text ) < 3 ) {
				return $m[0];
			}
			$translated = premium_shop_translate_wc_text( $text );
			return $translated === $text ? $m[0] : '>' . esc_html( $translated ) . '<';
		},
		$html
	);
}
add_filter( 'render_block', 'premium_shop_translate_wc_block_texts', 20, 2 );

/**
 * E-mails in another language than the one of the checkout (the shop's
 * "new order" e-mail for an order placed in French, or a French e-mail sent
 * from the German dashboard): product names and the payment method, stored on
 * the order in the checkout language, are shown in the e-mail's language.
 *
 * @param string             $name Item name (may contain a link).
 * @param WC_Order_Item|null $item Order item.
 * @return string
 */
function premium_shop_email_item_name( $name, $item = null ) {
	if ( empty( $GLOBALS['premium_shop_switched_language'] ) || ! $item instanceof WC_Order_Item_Product ) {
		return $name;
	}
	$product = $item->get_product();
	if ( ! $product ) {
		return $name;
	}
	$stored     = $item->get_name();
	$translated = $product->get_name();
	if ( '' === $stored || '' === $translated || $stored === $translated ) {
		return $name;
	}
	return str_replace( esc_html( $stored ), esc_html( $translated ), str_replace( $stored, $translated, $name ) );
}
add_filter( 'woocommerce_order_item_name', 'premium_shop_email_item_name', 20, 2 );

/**
 * Payment method title of an order in the e-mail's language.
 *
 * @param string $title Title stored on the order.
 * @return string
 */
function premium_shop_email_payment_title( $title ) {
	if ( empty( $GLOBALS['premium_shop_switched_language'] ) || ! is_string( $title ) || '' === $title ) {
		return $title;
	}
	return premium_shop_translate_setting_label( $title );
}
add_filter( 'woocommerce_order_get_payment_method_title', 'premium_shop_email_payment_title', 20 );

/**
 * WooCommerce texts in the visitor's language even when WooCommerce's
 * language pack for it is missing: the theme's own translation is used
 * ("In den Warenkorb" instead of "Add to cart").
 *
 * @param string $translation Translated text.
 * @param string $text        Original text.
 * @return string
 */
function premium_shop_wc_gettext_fallback( $translation, $text ) {
	static $keys = null;
	if ( $translation !== $text ) {
		return $translation;
	}
	if ( null === $keys ) {
		$keys = array_fill_keys( array_keys( premium_shop_wc_fallback_strings() ), true );
	}
	return isset( $keys[ $text ] ) ? translate( $text, 'premium-shop' ) : $translation; // phpcs:ignore WordPress.WP.I18n
}
add_filter( 'gettext_woocommerce', 'premium_shop_wc_gettext_fallback', 10, 2 );

/**
 * Download the missing WordPress and WooCommerce language packs (in the
 * background, after a theme update).
 */
function premium_shop_install_language_packs() {
	if ( ! function_exists( 'premium_shop_setup_languages' ) ) {
		$file = PREMIUM_SHOP_DIR . '/inc/admin/onboarding.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
	if ( function_exists( 'premium_shop_setup_languages' ) ) {
		premium_shop_setup_languages( false );
	}
}
add_action( 'premium_shop_install_language_packs', 'premium_shop_install_language_packs' );

/**
 * Theme update: schedule the language pack download.
 */
function premium_shop_schedule_language_packs() {
	if ( ! wp_next_scheduled( 'premium_shop_install_language_packs' ) ) {
		wp_schedule_single_event( time() + 30, 'premium_shop_install_language_packs' );
	}
}
add_action( 'premium_shop_upgrade_2_3_6', 'premium_shop_schedule_language_packs' );
